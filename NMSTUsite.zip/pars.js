// pars.js - Скрипт для поиска файлов и вывода их содержимого

// ===== НАСТРОЙКИ (изменяйте по необходимости) =====
const SEARCH_PATTERNS = [".php", ".sql", ".json", ".html"]; // маски для поиска
const OUTPUT_FILE = "output.txt"; // файл для сохранения результатов
const EXCLUDE_DIRS = ["node_modules", ".git", "dist", "build"]; // папки для исключения
const MAX_DEPTH = 10; // максимальная глубина поиска (0 = без ограничений)
// ====================================================

const fs = require("fs");
const path = require("path");

// Функция для проверки, соответствует ли файл маскам
function matchesPattern(filename) {
  return SEARCH_PATTERNS.some(pattern => {
    if (pattern.includes(".")) {
      return filename.endsWith(pattern);
    } else {
      return filename === pattern;
    }
  });
}

// Рекурсивная функция поиска файлов
function findFiles(dir, depth = 0) {
  let results = [];

  if (MAX_DEPTH > 0 && depth > MAX_DEPTH) {
    return results;
  }

  try {
    const items = fs.readdirSync(dir);

    for (const item of items) {
      const fullPath = path.join(dir, item);
      const stat = fs.statSync(fullPath);

      if (stat.isDirectory()) {
        // Пропускаем исключенные директории
        if (!EXCLUDE_DIRS.includes(item)) {
          results = results.concat(findFiles(fullPath, depth + 1));
        }
      } else if (stat.isFile() && matchesPattern(item)) {
        results.push(fullPath);
      }
    }
  } catch (err) {
    console.error(`Ошибка при чтении директории ${dir}:`, err.message);
  }

  return results;
}

// Функция для форматирования вывода
function formatOutput(files) {
  let output = "=== НАЙДЕННЫЕ ФАЙЛЫ ===\n";
  output += `Дата: ${new Date().toISOString()}\n`;
  output += `Количество файлов: ${files.length}\n\n`;

  files.forEach((file, index) => {
    const relativePath = path.relative(process.cwd(), file);
    const content = fs.readFileSync(file, "utf-8");

    output += `${"=".repeat(60)}\n`;
    output += `ФАЙЛ #${index + 1}: ${relativePath}\n`;
    output += `${"=".repeat(60)}\n`;
    output += content;
    output += `\n\n`;
  });

  return output;
}

// Главная функция
function main() {
  console.log("🔍 Начинаем поиск файлов...");
  console.log(`📁 Текущая директория: ${process.cwd()}`);
  console.log(`🔎 Маски поиска: ${SEARCH_PATTERNS.join(", ")}`);

  const foundFiles = findFiles(process.cwd());

  if (foundFiles.length === 0) {
    console.log("❌ Файлы не найдены");
    return;
  }

  console.log(`✅ Найдено файлов: ${foundFiles.length}`);

  // Форматируем и сохраняем результат
  const output = formatOutput(foundFiles);

  try {
    fs.writeFileSync(OUTPUT_FILE, output, "utf-8");
    console.log(`📄 Результат сохранен в файл: ${OUTPUT_FILE}`);
  } catch (err) {
    console.error("❌ Ошибка при сохранении файла:", err.message);
    // Выводим в консоль, если не удалось сохранить
    console.log("\n" + output);
  }
}

// Запускаем скрипт
main();